import axios from "axios";
import React, { useEffect, useState } from "react";
import Btn from "./Btn";

function Table() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    axios
      .get("https://my-json-server.typicode.com/sainparul19/projson/posts")
      .then((res) => {
        console.log(res);
        setPosts(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  return (
    <div>
      <table class="table table-success table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Email ID</th>
            <th scope="col">Amount Paid</th>
            <th scope="col">Mark as Paid</th>
          </tr>
        </thead>
        <tbody>
          {posts.map((post) => {
            return (
              <tr key={post.id}>
                <th scope="row">{post.id}</th>
                <td>{post.name}</td>
                <td>{post.email_id}</td>
                <td>
                  {post.is_paid} {post.is_paid ? "yes" : "no"}
                </td>
                <td>{post.is_paid ? " " : <Btn />}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default Table;
