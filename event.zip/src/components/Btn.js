import React, { useState } from "react";
import { StudentContext } from "../App";

function Btn() {
  const value = React.useContext(StudentContext);
  const [visible, setVisible] = useState(true);
  const [data, setData] = useState({ value });

  const handleClick = (index) => {
    const temp = data;
    console.log(data);
    temp[index].is_paid = true;
  };

  const removeElement = () => {
    setVisible((prev) => !prev);
  };

  return (
    <div>{visible && <button onClick={removeElement}>Not Paid</button>}</div>
  );
}

export default Btn;
